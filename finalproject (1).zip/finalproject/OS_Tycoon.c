#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Max limits
#define MAX_PROCESSES 10
#define MEMORY_SIZE 1024 // Simulated memory size

// Process States
typedef enum {
    READY,
    RUNNING,
    WAITING,
    TERMINATED
} ProcessState;

// Process Control Block
typedef struct {
    int pid;
    char name[20];
    int memory_needed;
    int cpu_time_needed;
    int cpu_time_used;
    ProcessState state;
} Process;

// Simulated Memory (just keeps track of used memory)
int used_memory = 0;

// Process Table
Process process_table[MAX_PROCESSES];
int process_count = 0;

// PID counter
int next_pid = 1;

// Function prototypes
void create_process();
void show_processes();
void scheduler();
void simulate_io(Process *proc);

void create_process() {
    if (process_count >= MAX_PROCESSES) {
        printf("❌ Process limit reached.\n");
        return;
    }

    Process p;
    p.pid = next_pid++;
    printf("Enter process name: ");
    scanf("%s", p.name);

    printf("Memory needed (1-%d): ", MEMORY_SIZE);
    scanf("%d", &p.memory_needed);

    printf("CPU time needed (in cycles): ");
    scanf("%d", &p.cpu_time_needed);

    if (used_memory + p.memory_needed > MEMORY_SIZE) {
        printf("❌ Not enough memory.\n");
        return;
    }

    p.cpu_time_used = 0;
    p.state = READY;

    process_table[process_count++] = p;
    used_memory += p.memory_needed;

    printf("✅ Process %s created with PID %d.\n", p.name, p.pid);
}

void show_processes() {
    printf("\n=== Process Table ===\n");
    for (int i = 0; i < process_count; i++) {
        Process p = process_table[i];
        printf("PID %d | %-10s | Mem: %d | CPU Used: %d/%d | ",
               p.pid, p.name, p.memory_needed, p.cpu_time_used, p.cpu_time_needed);

        switch (p.state) {
            case READY: printf("READY"); break;
            case RUNNING: printf("RUNNING"); break;
            case WAITING: printf("WAITING"); break;
            case TERMINATED: printf("TERMINATED"); break;
        }
        printf("\n");
    }
    printf("=====================\n");
}

void scheduler() {
    int all_terminated = 0;
    int cycle = 1;

    while (!all_terminated) {
        all_terminated = 1;
        printf("\n=== Scheduling Cycle %d ===\n", cycle);

        for (int i = 0; i < process_count; i++) {
            Process *p = &process_table[i];

            if (p->state == TERMINATED) continue;

            all_terminated = 0;

            if (p->state == WAITING) {
                // I/O completes here
                printf("Process %d (%s) I/O complete.\n", p->pid, p->name);
                p->state = READY;
            }

            if (p->state == READY) {
                p->state = RUNNING;
                printf("Running process %d (%s)...\n", p->pid, p->name);
                p->cpu_time_used++;

                if (p->cpu_time_used >= p->cpu_time_needed) {
                    p->state = TERMINATED;
                    used_memory -= p->memory_needed;
                    printf("Process %d completed.\n", p->pid);
                } else if (p->cpu_time_used % 2 == 0) {
                    simulate_io(p);
                } else {
                    p->state = READY;
                }
            }
        }

        cycle++;
        sleep(1); // Simulate time slice
    }

    printf("\n✅ All processes terminated.\n");
}

void simulate_io(Process *proc) {
    printf("Process %d performing I/O...\n", proc->pid);
    proc->state = WAITING;
}

int main() {
    int choice;

    while (1) {
        printf("\n=== Operating System Tycoon ===\n");
        printf("1. Create Process\n");
        printf("2. Show Processes\n");
        printf("3. Run Scheduler\n");
        printf("4. Exit\n");
        printf("Select an option: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                create_process();
                break;
            case 2:
                show_processes();
                break;
            case 3:
                scheduler();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid option.\n");
        }
    }
}
